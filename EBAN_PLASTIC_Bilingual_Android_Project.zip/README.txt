EBAN PLASTIC Android Project v2.1 (Bilingual)

WHAT IS INCLUDED
- Android Studio project source (not a compiled APK)
- English is the default app language; use the top-right button to switch to Amharic
- Offline local data storage on the device
- Admin and salesperson PIN entry
- Admin-only product creation and wholesale/retail price management
- Sales registration with wholesale/retail selection and partial payments
- Stock quantity deduction, customer list, expenses and sales reports
- JSON backup/restore and CSV sales export
- Currency display: ETB in English and ብር in Amharic

FIRST LOGIN (DEMO PINs)
- Admin PIN: 1234
- Salesperson PIN: 1111
Change the Admin PIN immediately in Reports > Admin Security.
This is a starter prototype. The PIN gate is app-level only and is not enterprise-grade
security. The salesperson PIN is currently a demo PIN and should be customized before
real business use. Do not store sensitive data until security has been professionally
reviewed.

IMPORTANT OFFLINE LIMITATION
Data is stored only on this phone. Multiple phones do not automatically share or
synchronize records. Back up regularly using the Backup button.

BUILD APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open and select the extracted project folder.
4. Allow Gradle sync to finish.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location. Transfer it to your Android phone and install.
This project uses Android Gradle Plugin 8.6.1, compileSdk 35 and minSdk 23.
